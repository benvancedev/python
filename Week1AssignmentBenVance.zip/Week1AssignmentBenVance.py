"""

    Program name: ENTD220

    Author: Ben Vance

    Data: Week 1 Assignment

    Notes: Sample Code

"""

# This is comment line

# This is test to see if Python is working.

myname="Ben Vance"

print("Hello ENTD220, My name is ", myname)

  
